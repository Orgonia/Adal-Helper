import "./env";
import { createHash } from "node:crypto";
import { existsSync } from "node:fs";
import { readdir, readFile } from "node:fs/promises";
import path from "node:path";
import mammoth from "mammoth";
import { TOPICS } from "@/lib/config";
import { chunkText } from "@/lib/chunker";
import { embedTexts } from "@/lib/gemini";
import {
  getChunksCollection,
  getClientPromise,
  getSourcesCollection,
} from "@/lib/mongodb";
import type { ChunkDoc } from "@/types";

const DOCS_DIR = path.join(process.cwd(), "data", "documents");
const SUPPORTED = new Set([".txt", ".md", ".pdf", ".docx"]);
const FORCE = process.argv.includes("--force");

interface Meta {
  title?: string;
  topic?: string;
  lang?: string;
}

async function loadManifest(): Promise<Record<string, Meta>> {
  const file = path.join(DOCS_DIR, "manifest.json");
  if (!existsSync(file)) return {};
  return JSON.parse(await readFile(file, "utf8"));
}

async function parsePdf(buffer: Buffer): Promise<string> {
  // Импортируем подмодуль напрямую: index у pdf-parse@1 запускает debug-код
  const modPath = "pdf-parse/lib/pdf-parse.js";
  const mod = await import(modPath);
  const pdfParse = mod.default ?? mod;
  const data = await pdfParse(buffer);
  return data.text as string;
}

async function extractText(file: string, buffer: Buffer): Promise<string> {
  switch (path.extname(file).toLowerCase()) {
    case ".pdf":
      return parsePdf(buffer);
    case ".docx":
      return (await mammoth.extractRawText({ buffer })).value;
    default:
      return buffer.toString("utf8");
  }
}

async function main() {
  if (!existsSync(DOCS_DIR)) {
    throw new Error(`Папка не найдена: ${DOCS_DIR}`);
  }

  const files = (await readdir(DOCS_DIR)).filter((f) =>
    SUPPORTED.has(path.extname(f).toLowerCase()),
  );
  if (files.length === 0) {
    console.log("В data/documents нет файлов (.txt .md .pdf .docx).");
    return;
  }

  const manifest = await loadManifest();
  const sources = await getSourcesCollection();
  const chunksCol = await getChunksCollection();

  for (const file of files) {
    const meta = manifest[file] ?? {};
    const title = meta.title ?? path.parse(file).name;
    const topic = meta.topic ?? "general";
    const lang = meta.lang ?? "ru";

    if (!(TOPICS as readonly string[]).includes(topic)) {
      console.warn(`⚠ ${file}: неизвестный topic "${topic}", допустимо: ${TOPICS.join(", ")}`);
    }

    const buffer = await readFile(path.join(DOCS_DIR, file));
    const hash = createHash("sha256")
      .update(buffer)
      .update(JSON.stringify({ title, topic, lang }))
      .digest("hex");

    const prev = await sources.findOne({ _id: file });
    if (prev?.hash === hash && !FORCE) {
      console.log(`↷ ${file}: без изменений, пропускаю`);
      continue;
    }

    console.log(`→ ${file}: извлекаю текст...`);
    const text = await extractText(file, buffer);
    const pieces = chunkText(text);
    if (pieces.length === 0) {
      console.warn(`⚠ ${file}: текст не извлечён (скан без OCR?), пропускаю`);
      continue;
    }

    console.log(`  ${pieces.length} фрагментов, считаю эмбеддинги...`);
    // В эмбеддинг добавляем название и заголовок: это улучшает поиск
    const inputs = pieces.map((c) =>
      [title, c.heading, c.text].filter(Boolean).join("\n"),
    );
    const vectors = await embedTexts(inputs, "RETRIEVAL_DOCUMENT");

    const now = new Date();
    const docs: ChunkDoc[] = pieces.map((c, i) => ({
      source: file,
      title,
      topic,
      lang,
      heading: c.heading,
      chunkIndex: i,
      text: c.text,
      embedding: vectors[i],
      createdAt: now,
    }));

    // Старые данные удаляем только после успешного получения эмбеддингов
    await chunksCol.deleteMany({ source: file });
    await chunksCol.insertMany(docs);
    await sources.updateOne(
      { _id: file },
      { $set: { title, topic, lang, hash, chunkCount: docs.length, updatedAt: now } },
      { upsert: true },
    );
    console.log(`✓ ${file}: записано ${docs.length} фрагментов`);
  }
}

main()
  .catch((err) => {
    console.error("Ошибка:", err);
    process.exitCode = 1;
  })
  .finally(async () => {
    const client = await getClientPromise().catch(() => null);
    await client?.close();
  });
